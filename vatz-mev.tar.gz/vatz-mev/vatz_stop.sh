#!/bin/bash

VATZ=vatz

killall $VATZ &>/dev/null || true
echo "$VATZ is killed ☠️a"
