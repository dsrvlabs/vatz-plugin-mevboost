#!/bin/bash

PLUGIN=mevboost-monitor
LOG=/var/log/mevboost-monitor/mevboost-monitor.log
DOCKER_CONTAINER=mev-boost-v1.3.1

$PLUGIN -mev-boost-version $DOCKER_CONTAINER >> $LOG 2>&1 &
echo "Good 💋"
