#!/bin/bash

VATZ=vatz
CONFIG=/root/bin/vatz/default.yaml
LOG=/var/log/vatz/vatz.log

$VATZ start --config $CONFIG >> $LOG 2>&1 &
echo "Good 💋"
