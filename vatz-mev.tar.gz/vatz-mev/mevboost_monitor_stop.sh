#!/bin/bash

PLUGIN=mevboost-monitor

killall $PLUGIN &>/dev/null || true
echo "$PLUGIN is killed ☠️a"
